-- AlterTable
ALTER TABLE "customization_settings" ADD COLUMN IF NOT EXISTS "catalogTermsAndConditions" TEXT;
