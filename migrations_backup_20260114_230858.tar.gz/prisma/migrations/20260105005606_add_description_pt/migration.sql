-- AlterTable
ALTER TABLE "EquipmentItem" ADD COLUMN     "descriptionPt" TEXT;
