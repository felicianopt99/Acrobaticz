-- Add logoUrl column to Partner
ALTER TABLE "Partner" ADD COLUMN "logoUrl" TEXT;
